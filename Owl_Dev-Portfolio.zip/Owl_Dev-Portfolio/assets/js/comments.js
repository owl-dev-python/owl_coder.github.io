let comments = JSON.parse(localStorage.getItem('comments')) || [];

function displayComments() {
    const container = document.getElementById('commentsDisplay');
    container.innerHTML = '';

    comments.forEach(comment => {
        const div = document.createElement('div');
        div.className = 'comment';
        div.innerHTML = `
            <strong>${comment.name || 'Anonymous'}</strong>
            <small>${new Date(comment.time).toLocaleString()}</small>
            <p>${comment.text}</p>
        `;
        container.appendChild(div);
    });
}

function postAnonComment() {
    const name = document.getElementById('anonName').value || 'Anonymous';
    const text = document.getElementById('anonComment').value.trim();

    if (!text) return alert('Please write a comment!');

    comments.push({
        name,
        text,
        time: Date.now(),
        type: 'anonymous'
    });

    localStorage.setItem('comments', JSON.stringify(comments));
    displayComments();
    document.getElementById('anonComment').value = '';
}

function postUserComment() {
    const name = document.getElementById('userName').value.trim();
    const text = document.getElementById('userComment').value.trim();

    if (!name || !text) return alert('Please fill all fields!');

    comments.push({
        name,
        text,
        time: Date.now(),
        type: 'user'
    });

    localStorage.setItem('comments', JSON.stringify(comments));
    displayComments();
    document.getElementById('userName').value = '';
    document.getElementById('userComment').value = '';
}

// Toggle forms
document.getElementById('anonBtn')?.addEventListener('click', function() {
    document.getElementById('commentFormAnon').classList.remove('hidden');
    document.getElementById('commentFormLogin').classList.add('hidden');
});

document.getElementById('loginBtn')?.addEventListener('click', function() {
    document.getElementById('commentFormLogin').classList.remove('hidden');
    document.getElementById('commentFormAnon').classList.add('hidden');
});

// Load comments on page load
displayComments();