// Check auth on load
checkAuth();

let uploadedItems = JSON.parse(localStorage.getItem('marketItems')) || [];

document.getElementById('uploadForm')?.addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('itemTitle').value;
    const desc = document.getElementById('itemDesc').value;
    const fileInput = document.getElementById('itemFile');
    const file = fileInput.files[0];

    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(event) {
        const item = {
            id: Date.now(),
            title,
            description: desc,
            fileUrl: event.target.result,
            fileType: file.type.startsWith('video') ? 'video' : 'image',
            uploadDate: new Date().toISOString()
        };

        uploadedItems.push(item);
        localStorage.setItem('marketItems', JSON.stringify(uploadedItems));
        displayItems();
        document.getElementById('uploadForm').reset();
        document.getElementById('preview').innerHTML = '';
        alert('Item uploaded successfully!');
    };
    reader.readAsDataURL(file);
});

// Preview file before upload
document.getElementById('itemFile')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('preview');
    preview.innerHTML = '';

    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            if (file.type.startsWith('image')) {
                const img = document.createElement('img');
                img.src = event.target.result;
                img.style.maxWidth = '200px';
                preview.appendChild(img);
            } else if (file.type.startsWith('video')) {
                const video = document.createElement('video');
                video.src = event.target.result;
                video.controls = true;
                video.style.maxWidth = '200px';
                preview.appendChild(video);
            }
        };
        reader.readAsDataURL(file);
    }
});

function displayItems() {
    const container = document.getElementById('itemsContainer');
    container.innerHTML = '';

    uploadedItems.forEach(item => {
        const div = document.createElement('div');
        div.className = 'item-card admin-item';
        div.innerHTML = `
            <h4>${item.title}</h4>
            <p>${item.description}</p>
            ${item.fileType === 'image' ? `<img src="${item.fileUrl}" alt="Preview">` : `<video src="${item.fileUrl}" controls></video>`}
            <button onclick="deleteItem(${item.id})">Delete</button>
        `;
        container.appendChild(div);
    });
}

function deleteItem(id) {
    uploadedItems = uploadedItems.filter(item => item.id !== id);
    localStorage.setItem('marketItems', JSON.stringify(uploadedItems));
    displayItems();
}

// Load items on page load
displayItems();