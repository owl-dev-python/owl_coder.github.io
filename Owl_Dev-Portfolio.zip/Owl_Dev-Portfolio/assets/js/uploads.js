document.addEventListener('DOMContentLoaded', function() {
    const items = JSON.parse(localStorage.getItem('marketItems')) || [];
    const container = document.getElementById('marketItems');

    if (items.length === 0) {
        container.innerHTML = '<p class="no-items">No items available yet. Check back soon!</p>';
        return;
    }

    items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'item-card';
        div.innerHTML = `
            <h3>${item.title}</h3>
            <p>${item.description}</p>
            ${item.fileType === 'image' ? `<img src="${item.fileUrl}" alt="${item.title}">` : `<video src="${item.fileUrl}" controls></video>`}
            <a href="https://discord.com/users/owl_coder" target="_blank" class="buy-btn">📩 DM to Buy</a>
        `;
        container.appendChild(div);
    });
});