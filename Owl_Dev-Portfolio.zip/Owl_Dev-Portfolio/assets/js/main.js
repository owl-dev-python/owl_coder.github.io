document.getElementById('loginForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('error');

    // Hardcoded credentials (since no backend)
    if (username === 'Owl_Dev' && password === 'owl0927dev2008') {
        localStorage.setItem('adminLoggedIn', 'true');
        localStorage.setItem('lastLogin', new Date().toISOString());
        window.location.href = 'admin.html';
    } else {
        errorEl.textContent = 'Invalid username or password.';
    }
});

// Logout function (call from admin panel)
function logout() {
    localStorage.removeItem('adminLoggedIn');
    localStorage.removeItem('lastLogin');
    window.location.href = 'login.html';
}

// Check if admin is logged in (redirect if not)
function checkAuth() {
    if (!localStorage.getItem('adminLoggedIn')) {
        window.location.href = 'login.html';
    }
}